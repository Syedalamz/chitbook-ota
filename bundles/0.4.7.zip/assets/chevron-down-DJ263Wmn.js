import{g as o}from"./index-BECNkJHp.js";const n=[["path",{d:"m6 9 6 6 6-6",key:"qrunsl"}]],c=o("chevron-down",n);export{c as C};
